This directory contains experimental features of cleverhans, which are not
integrated into main API yet.

